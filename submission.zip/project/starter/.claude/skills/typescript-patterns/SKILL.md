---
description: TypeScript type-safety review guidance, advanced patterns, and common type issues
---

# TypeScript Patterns

Use this skill when reviewing .ts and .tsx files.

## Type Safety Best Practices

- Enable and respect `strict` mode (`strictNullChecks`, `noImplicitAny`).
- Prefer `unknown` over `any`; narrow with type guards before use.
- Annotate public function parameters and return types explicitly.
- Use `readonly` and `as const` for data that should not change.
- Prefer `interface` for object shapes and `type` for unions and utilities.

## Advanced Patterns

- Discriminated unions with exhaustive `switch` checks (use a `never` default).
- Generics with constraints: `function f<T extends { id: string }>(x: T)`.
- Utility types: `Partial`, `Pick`, `Omit`, `Record`, `ReturnType`.
- Runtime validation (e.g. Zod) at trust boundaries, with `z.infer` for types.

## Common Type Issues

| Issue | Bad | Better | Severity |
|-------|-----|--------|----------|
| Explicit `any` | `data: any` | `data: unknown` + guard | medium |
| Unsafe assertion | `x as User` | validate or type guard | high |
| Non-null assertion | `user!.name` | `user?.name` / check | medium |
| Unhandled undefined | `arr[0].id` | check array/element first | medium |
| Missing return type | `function f(a)` | `function f(a: A): B` | low |
| `@ts-ignore` | `// @ts-ignore` | fix the type or `@ts-expect-error` with reason | medium |

```ts
// Bad
function getName(user: any) { return user.name.trim(); }

// Good
function getName(user: { name?: string }): string {
  return user.name?.trim() ?? '';
}
```

## Output

Return findings as a list. For each: file, line, category, severity
(critical/high/medium/low), a short explanation, and a suggested fix.
End with a short summary of overall type-safety quality.
