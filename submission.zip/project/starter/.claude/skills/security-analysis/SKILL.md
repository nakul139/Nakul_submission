---
description: Security-focused code review covering OWASP Top 10, secure coding practices, and common mistakes
---

# Security Analysis

Use this skill on ALL files, regardless of language.

## OWASP Top 10 Checklist

1. **Broken access control**: missing authorization checks, IDOR, trusting client-side roles.
2. **Cryptographic failures**: plaintext secrets or passwords, weak hashes (MD5, SHA1), `Math.random()` for tokens.
3. **Injection**: SQL/NoSQL/command injection from string concatenation; use parameterized queries.
4. **Insecure design**: no rate limiting, no input limits, missing threat consideration.
5. **Security misconfiguration**: debug mode on, permissive CORS (`*`), verbose error output.
6. **Vulnerable components**: outdated or unpinned dependencies with known CVEs.
7. **Authentication failures**: weak password rules, tokens in URLs, no session expiry.
8. **Integrity failures**: unsafe deserialization, unverified downloads or updates.
9. **Logging failures**: logging secrets/PII, or no logging of security events.
10. **SSRF**: fetching user-supplied URLs without an allowlist.

## Secure Coding Practices

- Validate and sanitize all input on the server side.
- Encode output for its context (HTML, SQL, shell).
- Load secrets from environment variables or a secret manager, never source code.
- Apply least privilege to tokens, DB users, and file access.
- Fail closed: deny by default on errors.

## Common Mistakes

```js
// Bad: SQL injection
db.query("SELECT * FROM users WHERE id = " + req.params.id);
// Good
db.query("SELECT * FROM users WHERE id = ?", [req.params.id]);

// Bad: XSS
el.innerHTML = userInput;
// Good
el.textContent = userInput;

// Bad: hardcoded secret
const apiKey = "sk-live-abc123";
// Good
const apiKey = process.env.API_KEY;

// Bad: command injection
exec("ls " + userPath);
// Good
execFile("ls", [userPath]);
```

Also flag: `eval`, `new Function`, disabled TLS verification, `dangerouslySetInnerHTML`
with unsanitized data, and secrets committed to the repo.

## Severity Guidelines

- **Critical**: remote code execution, auth bypass, exposed live secrets.
- **High**: injection, XSS, broken access control.
- **Medium**: weak crypto, missing validation, permissive CORS.
- **Low**: verbose errors, missing security headers.

## Output

For each finding: file, line, OWASP category, severity, explanation of the
risk, and a concrete fix. If no issues are found, say so explicitly.
